<?php
date_default_timezone_set('Asia/Ho_Chi_Minh');

$vnp_TmnCode = "4S5A6BNR";
$vnp_HashSecret = "UH7SFZBZJXTPTLJI8AOD5HPNR37LT6XY";
$vnp_Url = "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html";
$vnp_Returnurl = "https://techhubstore.io.vn/index.php?class=order&act=vnpay_return";
$vnp_apiUrl = "http://sandbox.vnpayment.vn/merchant_webapi/merchant.html";
$apiUrl = "https://sandbox.vnpayment.vn/merchant_webapi/api/transaction";
